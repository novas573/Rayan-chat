const express = require('express');
const http = require('http');
const cors = require('cors');
const { Server } = require('socket.io');
const admin = require('firebase-admin');

const app = express();
app.use(cors());
app.use(express.json({ limit: '1mb' }));
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*', methods: ['GET', 'POST'] } });

// On Render, set FIREBASE_SERVICE_ACCOUNT to the full JSON contents of a Firebase service-account key.
if (!admin.apps.length) {
  if (process.env.FIREBASE_SERVICE_ACCOUNT) {
    const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT);
    admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
  } else {
    admin.initializeApp({ credential: admin.credential.applicationDefault() });
  }
}
const db = admin.firestore();

async function verifyToken(token) {
  if (!token) throw new Error('Jeton Firebase manquant.');
  return admin.auth().verifyIdToken(token);
}
async function authMiddleware(req, res, next) {
  try {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : '';
    req.user = await verifyToken(token);
    next();
  } catch (_) {
    res.status(401).json({ error: 'Connexion requise. Connecte-toi avec Google dans Rayan Chat.' });
  }
}

app.get('/', (_req, res) => res.type('text').send('Rayan Chat Server fonctionne. Consulte /health.'));
app.get('/health', (_req, res) => res.json({ ok: true, service: 'rayan-chat-server', time: new Date().toISOString() }));

// Cherche un compte par son identifiant Rayan (exemple : 0612345678).
app.get('/api/users/:rayanId', authMiddleware, async (req, res) => {
  const id = String(req.params.rayanId || '').trim();
  if (!/^06\d{8}$/.test(id)) return res.status(400).json({ error: 'Identifiant Rayan invalide : il doit contenir 10 chiffres et commencer par 06.' });
  try {
    const snap = await db.collection('users').where('rayanId', '==', id).limit(1).get();
    if (snap.empty) return res.status(404).json({ error: 'Aucun compte Rayan Chat trouvé.' });
    const doc = snap.docs[0];
    const data = doc.data();
    return res.json({ uid: doc.id, rayanId: data.rayanId, displayName: data.displayName || '', photoURL: data.photoURL || '' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erreur de recherche. Vérifie la configuration Firestore.' });
  }
});

// Récupère les derniers messages d'une conversation. chatId doit être identique pour les deux participants.
app.get('/api/chats/:chatId/messages', authMiddleware, async (req, res) => {
  const chatId = String(req.params.chatId || '');
  if (!/^[A-Za-z0-9_-]{1,160}$/.test(chatId)) return res.status(400).json({ error: 'Identifiant de conversation invalide.' });
  try {
    const snap = await db.collection('chats').doc(chatId).collection('messages').orderBy('createdAt', 'desc').limit(50).get();
    res.json({ messages: snap.docs.map(d => ({ id: d.id, ...d.data() })).reverse() });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Impossible de charger les messages.' });
  }
});

io.use(async (socket, next) => {
  try {
    socket.user = await verifyToken(socket.handshake.auth && socket.handshake.auth.token);
    next();
  } catch (_) { next(new Error('Authentification Firebase requise')); }
});

io.on('connection', socket => {
  socket.on('chat:join', async ({ chatId } = {}, ack = () => {}) => {
    if (typeof chatId !== 'string' || !/^[A-Za-z0-9_-]{1,160}$/.test(chatId)) return ack({ ok: false, error: 'Identifiant invalide.' });
    socket.join(`chat:${chatId}`);
    ack({ ok: true });
  });

  socket.on('chat:send', async (payload = {}, ack = () => {}) => {
    try {
      const chatId = String(payload.chatId || '');
      const text = String(payload.text || '').trim();
      if (!/^[A-Za-z0-9_-]{1,160}$/.test(chatId)) return ack({ ok: false, error: 'Identifiant de conversation invalide.' });
      if (!text || text.length > 5000) return ack({ ok: false, error: 'Le message doit contenir entre 1 et 5000 caractères.' });
      const userRecord = await admin.auth().getUser(socket.user.uid);
      const message = {
        senderUid: socket.user.uid,
        senderName: userRecord.displayName || '',
        text,
        createdAt: admin.firestore.FieldValue.serverTimestamp()
      };
      const ref = await db.collection('chats').doc(chatId).collection('messages').add(message);
      const saved = { id: ref.id, ...message, createdAt: new Date().toISOString() };
      io.to(`chat:${chatId}`).emit('chat:new-message', saved);
      ack({ ok: true, message: saved });
    } catch (err) {
      console.error(err);
      ack({ ok: false, error: 'Envoi impossible. Vérifie Firestore et les permissions du serveur.' });
    }
  });
});

const port = process.env.PORT || 3000;
server.listen(port, '0.0.0.0', () => console.log(`Rayan Chat Server écoute sur ${port}`));
